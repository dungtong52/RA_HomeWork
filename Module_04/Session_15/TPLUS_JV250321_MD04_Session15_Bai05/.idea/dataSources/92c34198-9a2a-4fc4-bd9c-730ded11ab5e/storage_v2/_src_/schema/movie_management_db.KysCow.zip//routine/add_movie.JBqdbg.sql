create
    definer = root@`%` procedure add_movie(IN in_title varchar(100), IN in_director varchar(100), IN in_year int)
begin
    insert into movies(movie_title, director, year)
        values (in_title,in_director,in_year);
end;

