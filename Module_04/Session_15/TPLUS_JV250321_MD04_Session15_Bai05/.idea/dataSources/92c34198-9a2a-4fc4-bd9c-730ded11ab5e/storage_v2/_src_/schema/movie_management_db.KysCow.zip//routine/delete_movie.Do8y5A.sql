create
    definer = root@`%` procedure delete_movie(IN in_id int)
begin
    delete from movies where movie_id = in_id;
end;

