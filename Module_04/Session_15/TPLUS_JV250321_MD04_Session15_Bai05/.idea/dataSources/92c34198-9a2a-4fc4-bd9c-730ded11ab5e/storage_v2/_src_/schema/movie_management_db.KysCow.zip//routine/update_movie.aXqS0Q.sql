create
    definer = root@`%` procedure update_movie(IN in_id int, IN in_title varchar(100), IN in_director varchar(100),
                                              IN in_year int)
begin
    update movies m
        set m.movie_title = in_title,
            m.director = in_director,
            m.year = in_year
    where m.movie_id = in_id;
end;

