create
    definer = root@`%` procedure get_all_movies()
begin
    select m.movie_id, m.movie_title, m.director, m.year
    from movies m;
end;

