create
    definer = root@`%` procedure find_movie_by_id(IN in_id int)
begin
    select m.movie_id, m.movie_title, m.director, m.year
    from movies m
    where movie_id = in_id;
end;

