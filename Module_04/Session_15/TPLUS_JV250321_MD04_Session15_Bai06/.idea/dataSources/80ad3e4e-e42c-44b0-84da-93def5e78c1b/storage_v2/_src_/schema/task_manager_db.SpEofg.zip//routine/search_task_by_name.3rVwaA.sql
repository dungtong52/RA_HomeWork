create
    definer = root@`%` procedure search_task_by_name(IN in_name varchar(100))
begin
    select t.task_id, t.task_name, t.status
    from tasks t
    where task_name like concat('%', in_name,'%');
end;

