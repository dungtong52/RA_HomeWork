create
    definer = root@`%` procedure search_task_by_id(IN in_id int)
begin
    select t.task_id, t.task_name, t.status
    from tasks t
    where task_id = in_id;
end;

