create
    definer = root@`%` procedure get_all_tasks()
begin
    select t.task_id, t.task_name, t.status
    from tasks t;
end;

