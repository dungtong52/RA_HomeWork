create
    definer = root@`%` procedure delete_task(IN in_id int)
begin
    delete from tasks where task_id = in_id;
end;

