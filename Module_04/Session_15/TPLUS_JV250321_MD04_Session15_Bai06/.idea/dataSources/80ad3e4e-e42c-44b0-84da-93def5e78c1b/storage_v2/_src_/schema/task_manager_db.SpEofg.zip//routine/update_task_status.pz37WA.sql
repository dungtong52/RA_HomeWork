create
    definer = root@`%` procedure update_task_status(IN in_id int, IN in_status varchar(100))
begin
    update tasks
    set status = in_status
    where task_id = in_id;
end;

