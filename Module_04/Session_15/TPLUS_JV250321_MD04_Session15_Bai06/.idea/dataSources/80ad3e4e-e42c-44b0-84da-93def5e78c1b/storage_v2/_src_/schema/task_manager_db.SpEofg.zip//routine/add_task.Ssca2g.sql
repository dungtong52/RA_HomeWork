create
    definer = root@`%` procedure add_task(IN in_name varchar(100), IN in_status tinyint(1))
begin
    insert into tasks (task_name, status)
    values (in_name, in_status);
end;

