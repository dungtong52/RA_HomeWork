create
    definer = root@`%` procedure task_statistic()
begin
    select t.status, count(t.task_id) as 'count_task'
    from tasks t
    group by t.status;
end;

