create
    definer = root@`%` procedure get_bus_by_id(IN p_id int)
begin
    select * from bus where id = p_id;
end;

