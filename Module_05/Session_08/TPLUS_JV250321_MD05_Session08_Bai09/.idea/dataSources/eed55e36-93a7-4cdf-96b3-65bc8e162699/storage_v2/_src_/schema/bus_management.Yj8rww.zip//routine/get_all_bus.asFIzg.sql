create
    definer = root@`%` procedure get_all_bus()
begin
    select * from bus;
end;

