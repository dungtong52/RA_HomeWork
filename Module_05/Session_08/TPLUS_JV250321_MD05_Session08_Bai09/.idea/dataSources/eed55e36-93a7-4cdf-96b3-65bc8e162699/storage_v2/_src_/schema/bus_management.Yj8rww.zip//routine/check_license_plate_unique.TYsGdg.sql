create
    definer = root@`%` procedure check_license_plate_unique(IN p_id int, IN p_license_plate varchar(20))
begin
    select count(*) as cnt
    from bus
    where license_plate = p_license_plate
      and id <> p_id;
end;

