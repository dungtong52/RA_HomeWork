create
    definer = root@`%` procedure update_bus(IN p_id int, IN p_license_plate varchar(20), IN p_bus_type varchar(20),
                                            IN p_row_seat int, IN p_col_seat int, IN p_image varchar(255))
begin
    update bus
    set license_plate = p_license_plate,
        bus_type      = p_bus_type,
        row_seat      = p_row_seat,
        col_seat      = p_col_seat,
        image         = p_image
    where id = p_id;
end;

