create
    definer = root@`%` procedure delete_bus(IN p_id int)
begin
    delete from bus where id = p_id;
end;

