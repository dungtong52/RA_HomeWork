create
    definer = root@`%` procedure add_bus(IN p_license_plate varchar(20), IN p_bus_type varchar(20), IN p_row_seat int,
                                         IN p_col_seat int, IN p_image varchar(255))
begin
    insert into bus (license_plate, bus_type, row_seat, col_seat, image)
    values (p_license_plate, p_bus_type, p_row_seat, p_col_seat, p_image);
end;

